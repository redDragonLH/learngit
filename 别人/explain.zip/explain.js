$(function(){
	function getCookie(cookie_name){   
		var allcookies = document.cookie;  
		var cookie_pos = allcookies.indexOf(cookie_name); 
		if (cookie_pos != -1){   
			cookie_pos += cookie_name.length + 1;          
			var cookie_end = allcookies.indexOf(";", cookie_pos);    
		if (cookie_end == -1){    
			cookie_end = allcookies.length;    
		}      
			var value = unescape(allcookies.substring(cookie_pos, cookie_end));     
		}      
			return value;    
	} 
	function getQueryString(name) { 
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
		var r = window.location.search.substr(1).match(reg); 
		if (r != null) return unescape(r[2]); return ''; 
	}
	var club_id=getCookie("club_id");
	var source=getQueryString("source");
	var way=getQueryString("way");
//	var club_id=32;
//数据
	var jsonE;
	var data;
	var app_id;
	var app_secret;
	var encoding_aes_key;
	var choose_way;
	var account;
	var password;
	var id;
	
	//传递数据			
	var p_data=iwetuan_add+"/api/club/ClubWechatInfo?club_id="+club_id;
	if(source!="fail"){
	    $.ajax({
		 	type:"get",
		 	url:p_data,
		 	async:true,
		 	success:function(respose){
		 		jsonE=eval('(' + respose + ')');
		 		data=jsonE.data;		
				//判断接口是否有数据 			
		 		if(jsonE.error_code==0){
				//判断成功失败
				//接口数据 	
					choose_way=data[0].choose_way;
		 			app_id=data[0].app_id;
	 				app_secret=data[0].app_secret;
		 			encoding_aes_key=data[0].encoding_aes_key;
		 			account=data[0].account;
		 			password=data[0].password;
		 			id=data[0].id;
		 			//数据回显 	
				 		//手动
						if(way==1){
							if(choose_way==1){	
					 			$(".handF").val(app_id);
					 			$(".handS").val(app_secret);
					 			$(".handT").val(encoding_aes_key);
							}
						}
						//客服
						else if(way==2){
							if(choose_way==2){	
					 			$(".kkk:eq(0)").val(account);
					 			$(".kkk:eq(1)").val(password);
					 			$(".kkk:eq(2)").val(app_id);
					 			$(".kkk:eq(3)").val(app_secret);
							}
						}else{
							if(data[0].status==1){
				 				window.location.href=iwetuan_add+"/wechat/tip?type=success";
				 			}else if(data[0].status==0){
				 				window.location.href=iwetuan_add+"/wechat/tip?type=fail"; 
				 			}else if(data[0].status==2){
				 				window.location.href=iwetuan_add+"/wechat/tip?type=wait"; 
				 			}
						}
			 	}else{
			 			id=0;
			 			$(".activity-series-public-page").show();
			 	}
		 		
		 	}
		}) 
	}else{
		$(".activity-series-public-page").show();
	}
//显示二维码	
	$(".Hover").mouseover(function(){
		$(".Show").show();
	}).mouseleave(function(){
		$(".Show").hide();
	})
//点击跳转
//点击手动接入
	$(".hand").bind("click",function(){
		window.location.href=iwetuan_add+"/wechat/hand?way=1";				
	})
//点击客服接入	
	$(".service").bind("click",function(){
		window.location.href=iwetuan_add+"/wechat/service?way=2";
	})
	
//手动接入

//判断输入内容不能为空
//单独判断每个文本框,要不在第一个失去焦点时,提示信息会都出现
	$(".handF").blur(function(){
		var handF=$(".handF").val();
		if(handF.length==""){
			$(".handcheck").eq(0).show();
		}else{
			$(".handcheck").eq(0).hide();
		}
	})
	$(".handS").blur(function(){
		var handS=$(".handS").val();
		if(handS.length==""){
			$(".handcheck").eq(1).show();
		}else{
			$(".handcheck").eq(1).hide();
		}
	})
	$(".handT").blur(function(){
		var handT=$(".handT").val();
		if(handT.length==""){
			$(".handcheck").eq(2).show();
		}else{
			$(".handcheck").eq(2).hide();
		}
	})
//点击提交
	$(".posT").bind("click",function(){	
		if($(".handF").val().length!= "" && $(".handS").val().length!= "" && $(".handT").val().length!= ""){
			$(".box").show(800);
//传递数据		
			console.log(id)
			hand(id,1,$(".handF").val(),$(".handS").val(),$(".handT").val(),"","");	
		}else{
			var notices=layer.open({
	          title: '提醒',
	          content: '<p style="text-align: center;font-size: 15px;margin-bottom:10px;">请将信息填写完整。</p>',
	          button: '确定',
		//	  closeBtn: false,
	          move: false,
	          yes: function(){
				 layer.close(notices);
		    
	          }
	      });
		}				
	})
//传递数据		
	var post_data=iwetuan_add+"/api/club/AUWechatConfig";
	function goAjax(paramObj,urlStr){
		if(!paramObj) {
			paramObj = {};
		}
		return $.ajax({
			url: post_data,
			type: 'POST',
			jsonp: "callback",
			dataType: "json",
			async: false,
			cache: true,
			data: paramObj,
		});
	};
	function hand(ko,ok,aa,bb,cc,dd,ee){
		goAjax({
			"id":ko,
			"club_id":club_id,
			"app_id":aa,
			"app_secret":bb,
			"encoding_aes_key":cc,
			"account":dd,
			"password":ee,
			"choose_way":ok	
		},post_data).done(function(res){
			if(res.error_code == 0){
				$(".Url").val(res.url);
				$(".Token").val(res.token);  
			}
			
		})
	}
	
	
	
//一键复制URL	
	var clip = new ZeroClipboard( document.getElementById("copy") );
//一键复制Token	
	var Clip = new ZeroClipboard( document.getElementById("Copy") );
	$("#copy").bind("click",function(){
		$(".copySuccess").eq(0).show();
		setTimeout(function(){
			$(".copySuccess").eq(0).hide();
		},2000)
	})
	$("#Copy").bind("click",function(){
		$(".copySuccess").eq(1).show();
		setTimeout(function(){
			$(".copySuccess").eq(1).hide();
		},2000)
	})

//客服接入
	
	//判断输入内容不能为空
	//单独判断每个文本框,要不在第一个失去焦点时,提示信息会都出现
	$(".kkk").eq(0).blur(function(){
		if($(".kkk").eq(0).val().length==""){
			$(".NULL").eq(0).show();
		}else{
			$(".NULL").eq(0).hide();
		}
	})
	$(".kkk").eq(1).blur(function(){
		if($(".kkk").eq(1).val().length==""){
			$(".NULL").eq(1).show();
		}else{
			$(".NULL").eq(1).hide();
		}
	})
	$(".kkk").eq(2).blur(function(){
		if($(".kkk").eq(2).val().length==""){
			$(".NULL").eq(2).show();
		}else{
			$(".NULL").eq(2).hide();
		}
	})
	$(".kkk").eq(3).blur(function(){
		if($(".kkk").eq(3).val().length==""){
			$(".NULL").eq(3).show();
		}else{
			$(".NULL").eq(3).hide();
		}
	})
	
//点击提交
	$(".Cservice").bind("click",function(){	
		if($(".kkk").eq(0).val().length!= "" && $(".kkk").eq(1).val().length!= "" && $(".kkk").eq(2).val().length != "" && $(".kkk").eq(3).val().length){
			var ok=layer.open({
	          title: '提醒',
	          content: '<p style="text-align: left;font-size: 15px;margin-bottom:10px;">恭喜您微信接入申请提交成功。</p><p style="text-align: left;font-size: 15px;margin-bottom:10px;">爱微团客服将在24小时之内（工作日）完成。</p><p style="text-align: left;font-size: 15px;margin-bottom:10px;">请耐心等待。</p>',
	          btn: ['好的'],
		//	  closeBtn: false,
	          move: false,
	          yes: function(){
				 layer.close(ok);
		    	 window.location.href=iwetuan_add+"/wechat/tip?type=wait";	
	          }
	     });
			hand(id,2,$(".kkk").eq(2).val(),$(".kkk").eq(3).val(),"",$(".kkk").eq(0).val(),$(".kkk").eq(1).val());	
			$("input").attr("readonly","readonly");
//传递数据			
			//addLeader();
		}else{
			var notices=layer.open({
	          title: '提醒',
	          content: '<p style="text-align: center;font-size: 15px;margin-bottom:10px;">请将信息填写完整。</p>',
	          button: '确定',
		//	  closeBtn: false,
	          move: false,
	          yes: function(){
				 layer.close(notices);
		    
	          }
	      });
		}
	})
	
	/*左侧导航操蛋选中事件*/
  if (window.Nav && window.Nav.showActiveSubItem && $.isFunction(window.Nav.showActiveSubItem)) {
      window.Nav.showActiveSubItem(6, 0);
  }
  else {
      $('body').bind('NavComplish', function() {
          window.Nav.showActiveSubItem(6, 0);
      });
  }
})




































































































































































































































